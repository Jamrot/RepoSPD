# Copyright (c) Meta Platforms, Inc. and affiliates.
# This software may be used and distributed according to the terms of the Llama 2 Community License Agreement.

from typing import Optional


from tqdm import tqdm

import os
import jsonlines

import json
import requests
def main(

    temperature: float = 0.0,
    top_p: float = 0.95,
    max_seq_len: int = 512,
    max_batch_size: int = 32,
    max_gen_len: Optional[int] = None,
):
    url = 'http://localhost:11434/api/chat'

    prompt = 'You are an vulnerability expert in C/C++. Decide whether a commit patch is a vulnerability-related security patch or not?  You can only answer [Yes] or [No]. If [Yes], it means the patch fixes vulnerablities. If [No], it means the patch doesn\'t fixes any vulnerability.'
    
    prompt_1 = 'Decide whether the following commit patch is a vulnerability-related security patch or not?  You can only answer [Yes] or [No]. If [Yes], it means the patch fixes vulnerablities. If [No], it means the patch doesn\'t fixes any vulnerability. \n Patch:\n  '
    filename = '/new_data/xcwen/llama3/SPD/data/SPI-DB/spi_db_dev_final.jsonl'
    writepath = './spi_db_dev_result.jsonl'
    querys = []
    number = 1

    total = 1
    with jsonlines.open(filename) as reader:
        for obj in reader:
            querys.append(obj)
            # querys = querys[int((number-1)*(len(querys)/total)):int((number)*(len(querys)/total))]

    results = []
    fail = []
    for pos in tqdm(range(len(querys)), desc=f'Testing'):
        query = querys[pos]
        idx = query['commit_id']
        code = query['diff_code']
        data = {
            "model": "llama3:70b",
            "messages": 
            [
                {
                    "role": "system",
                    "content": prompt,
                },
                {
                    "role": "user",
                    "content": prompt_1 + code + '\nAnswer:',
                }
            ],
            "stream": False
        }

        # messages = [
    
        #     [
        #         {
        #             "role": "system",
        #             "content": prompt,
        #         },
        #         {
        #             "role": "user",
        #             "content": prompt_1 + code,
        #         }
        #     ],
        # ]
        try:
            results = requests.post(url, json=data)
            with open(writepath, 'a') as f:
                result1 = {}
                result1['commit_id'] = query['commit_id']
                result1['target'] = query['category']
                for chunk in results.iter_lines():
                    if chunk:
                        # print(chunk)
                        chunk = chunk.decode('utf-8')
                        chunk = json.loads(chunk)
                        content = chunk['message']['content']
                        
                        #print(content, end="", flush=True)
                        result1['answer'] = content
                        f.write((json.dumps(result1, ensure_ascii=False) + "\n"))

        except Exception as e:
            print(e)
            print("Error:" + str(idx))



if __name__ == "__main__":

    os.environ["CUDA_VISIBLE_DEVICES"] = "1"
    main()
